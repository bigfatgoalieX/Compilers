// struct Tree_Node{
//     struct Tree_Node* child;
//     struct Tree_Node* next_sib;
//     char name[32];
//     union{
//         long long is_int;
//         float is_float;
//         char is_string[32];
//     };
//     int height;
//     int lineno;
//     NODE_TYPE type;
// }